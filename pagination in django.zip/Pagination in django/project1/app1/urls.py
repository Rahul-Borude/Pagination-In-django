from django.urls import path 
from app1.views import Studentlistview


urlpatterns = [
    path('pv/',Studentlistview.as_view(),name='home')
]
