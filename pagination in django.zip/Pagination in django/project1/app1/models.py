from django.db import models

# Create your models here.
class Student(models.Model):
    rn = models.IntegerField()
    fname = models.CharField(max_length=150)
    lname = models.CharField(max_length=150)
    phone = models.CharField(max_length=150)
    email = models.CharField(max_length=150)

    def __str__(self):
        return self.phone