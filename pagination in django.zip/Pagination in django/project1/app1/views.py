from django.shortcuts import render
from app1.models import Student
from django.core.paginator import Paginator, EmptyPage
from django.views.generic import ListView
# Create your views here.

class Studentlistview(ListView):
    model = Student
    template_name = "app1/home.html"
    ordering = ['id']
    paginate_by = 3
    queryset = Student.objects.all()
    

